# VFC Patcher Solution v2 (C# 7.3-compatible, Debug/Release configs)

## Fixes included
- Converted CustomAction.cs to **C# 7.3-compatible** (no `using var` declarations).
- Added **Debug/Release** configurations and `OutputPath` to avoid the "OutputPath property is not set" error.
- Set `<LangVersion>latest</LangVersion>` in the CA project (safe even with C# 7.3 code).
- WiX project imports `Wix.targets` using the standard **MSBuild extensions path**.

## Prerequisites
- **WiX Toolset 3.14** (installs `Wix.targets` and `WixUIExtension`)  
- **.NET Framework 4.8 Developer Pack**  
- Visual Studio with **.NET desktop development** workload

## Build Steps
1. Open `VFC_Patcher.sln` in Visual Studio.
2. **Restore NuGet** packages for the CA project:
   - `WixToolset.Dtf.WindowsInstaller`
   - `WixToolset.Dtf.CustomAction`
   - `DocumentFormat.OpenXml`
3. Build **VFC.Patcher.CustomAction** in **Release**.
4. Merge into single CA DLL (recommended):
   ```powershell
   ILRepack.exe /ndebug /wildcards /lib:bin\Release      /out:..\VFC.Patcher.Setup\Binaries\CustomAction.CA.dll      bin\Release\VFC.Patcher.CustomAction.dll      bin\Release\DocumentFormat.OpenXml.dll
   ```
5. Replace `VFC.Patcher.Setup\Files\payloaderbastorage.exe` with your real patched exe.
6. Build **VFC.Patcher.Setup** (Debug or Release) → `VFC Patching Tool.msi`.
